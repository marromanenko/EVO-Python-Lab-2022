Web service. There is a form with a name entry field and a "Hello" button On the main page. When you click on the button, 
if the name first appeared, display "Hello, <Name + Surname>" or "Hello, <email>" (of your choice). If such a name has already been found, 
we display "Already seen, name".

There is also a link on the main page, which, when clicked, shows a list of everyone you have already greeted.

User data is stored in a database py_sweater. Used PostgreSQL and Python.